import express from 'express';
import Poll from '../models/Poll.js';

const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const poll = new Poll(req.body);
    await poll.save();
    res.json(poll);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/:eventId', async (req, res) => {
  const polls = await Poll.find({ event: req.params.eventId });
  res.json(polls);
});

router.post('/:pollId/vote', async (req, res) => {
  try {
    const { optionIndex } = req.body;
    const poll = await Poll.findById(req.params.pollId);
    poll.options[optionIndex].votes += 1;
    await poll.save();
    res.json(poll);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
