import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api';

function EventPage() {
  const { id } = useParams();
  const [polls, setPolls] = useState([]);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState('');

  useEffect(() => {
    api.get(`/polls/${id}`).then(res => setPolls(res.data));
  }, [id]);

  const createPoll = async () => {
    const poll = { event: id, question, options: options.split(',').map(o => ({ text: o })) };
    const res = await api.post('/polls', poll);
    setPolls([...polls, res.data]);
  };

  const vote = async (pollId, idx) => {
    const res = await api.post(`/polls/${pollId}/vote`, { optionIndex: idx });
    setPolls(polls.map(p => (p._id === pollId ? res.data : p)));
  };

  return (
    <div>
      <h2>Event Polls</h2>
      <input placeholder='Question' value={question} onChange={e => setQuestion(e.target.value)} />
      <input placeholder='Options (comma separated)' value={options} onChange={e => setOptions(e.target.value)} />
      <button onClick={createPoll}>Create Poll</button>

      {polls.map(poll => (
        <div key={poll._id}>
          <h3>{poll.question}</h3>
          {poll.options.map((opt, i) => (
            <button key={i} onClick={() => vote(poll._id, i)}>
              {opt.text} ({opt.votes})
            </button>
          ))}
        </div>
      ))}
    </div>
  );
}

export default EventPage;
