import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../api';

function Dashboard() {
  const [events, setEvents] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    api.get('/events').then(res => setEvents(res.data));
  }, []);

  const createEvent = async () => {
    const res = await api.post('/events', { title, description });
    setEvents([...events, res.data]);
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <input placeholder='Event Title' value={title} onChange={e => setTitle(e.target.value)} />
      <input placeholder='Description' value={description} onChange={e => setDescription(e.target.value)} />
      <button onClick={createEvent}>Create Event</button>
      <ul>
        {events.map(ev => (
          <li key={ev._id}><Link to={`/events/${ev._id}`}>{ev.title}</Link></li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
