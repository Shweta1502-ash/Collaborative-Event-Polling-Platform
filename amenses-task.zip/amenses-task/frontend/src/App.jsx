import React from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import EventPage from './pages/EventPage';

function App() {
  return (
    <div>
      <nav>
        <Link to='/'>Dashboard</Link> | <Link to='/login'>Login</Link> | <Link to='/signup'>Signup</Link>
      </nav>
      <Routes>
        <Route path='/' element={<Dashboard />} />
        <Route path='/login' element={<Login />} />
        <Route path='/signup' element={<Signup />} />
        <Route path='/events/:id' element={<EventPage />} />
      </Routes>
    </div>
  );
}

export default App;
